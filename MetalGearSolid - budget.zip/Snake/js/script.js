//Listeners
document.addEventListener('keydown', keyPush)


//Canvas

const canvas = document.querySelector("canvas");
const title  = document.querySelector("h1");
const ctx = canvas.getContext ("2d");


//player

const snakeSize = 50;

let snakeSpeed = snakeSize;
let snakePosX = 0;
let snakePosY = canvas.height / 2;


let velocityX = 1;
let velocityY = 0;

//tiles
const tileCountX = canvas.width / snakeSize;
const tileCountY = canvas.height / snakeSize;

//fooood bar
let foodPosX = 0;
let foodPosY = 0;

//game
let gameIsRunning = true;

let score = 0;
let tail = [];
let snakeLength = 2;



//loop
//
function gameLoop () {

if ( gameIsRunning) {
drawStuff();
moveStuff();
setTimeout(gameLoop, 1000 / 15);
  }
}

resetFood();
gameLoop();


/** move everything */
function moveStuff() {

snakePosX += snakeSpeed * velocityX;
snakePosY += snakeSpeed * velocityY;

// snakePosX += snakeSpeed;



// Wall collision

if (snakePosX > canvas.width - snakeSize) {
	snakePosX = 0;
 }
 if (snakePosX < 0) {
	snakePosX = canvas.width;
 }
 if (snakePosY > canvas.height - snakeSize) {
	snakePosY = 0;
 }
 if (snakePosY < 0) {
	snakePosY = canvas.height;
 }


tail.forEach(( snakePart) => {
	if (snakePosX === snakePart.x && snakePosY === snakePart.y) {
		gameIsRunning = false;
		window.open('https://www.youtube.com/watch?v=Mpcobk9uFz0&ab_channel=K%C3%A9vinTUR', '', 'width=600,height=300' );
	}
});

//tail
tail.push({ x: snakePosX, y: snakePosY});

// forget earliest parts of snake (pamata si kocky s kolkymi zaciname)
tail = tail.slice(-1 * snakeLength);


 //food collision

 	if (snakePosX === foodPosX && snakePosY === foodPosY) {
 		title.textContent = ++score;
 		snakeLength++;
 		resetFood();
 	}

}

/**
 * DRAW EVERYTHING
 */
"#ccd6d9";
function drawStuff() {
	//background
	rectangle('#f3f5f6',0,0, canvas.width, canvas.height);

	//grid
 	 drawGrid()

 	//food
 	rectangle('#e80c15', foodPosX, foodPosY, snakeSize, snakeSize);

 	//tail
 	tail.forEach((snakePart) =>
 		rectangle('#e80c15', snakePart.x, snakePart.y, snakeSize, snakeSize)
 		);

 	// snake
	rectangle('#87070c', snakePosX, snakePosY, snakeSize, snakeSize);
}

//draw rectangle
function rectangle(color, x, y, width, height) {
		ctx.fillStyle = color;
		ctx.fillRect(x, y, width, height);

}

// randomize FOOOOOD
  function resetFood() {
  foodPosX	= Math.floor(Math.random() * tileCountX) * snakeSize;
  foodPosY 	= Math.floor(Math.random() * tileCountY) * snakeSize;
  }

/**
 * KEYBOARD
 */


function keyPush(event) {
	switch(event.key) {
	  case "ArrowLeft":
	   if (velocityX !== 1) {
		velocityX = -1;
		velocityY = 0;
	  }
		break;
	  case "ArrowUp":
	  	if (velocityY !== 1) {
	  	velocityX = 0;
	  	velocityY = -1;
	  }
		break;
	  case "ArrowRight":
	   if (velocityX !== -1) {
	  	velocityX = 1;
	  	velocityY = 0;
	  }
		break;
	  case "ArrowDown":
	   if (velocityY !== -1) {
	  	velocityX = 0;
	  	velocityY = 1;
	  }
		break;
	default:
	//restart ga,e
	if (!gameIsRunning) location.reload();
	break;
	}
}


//grid
function drawGrid() {
	for (let i = 0; i < tileCountX; i++) {
		for (let j = 0; j < tileCountY; j++) {
 		rectangle (
 		"#ccd6d9",
 		snakeSize * i,
 		snakeSize * j,
 		snakeSize - 1,
 		snakeSize - 1
 		);
 	}
  }
}